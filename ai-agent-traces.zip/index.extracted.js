
'use strict';
/* =========================================================================
   OVERRIDE — audio-first browser dungeon shooter
   All rendering is canvas primitives, all audio is procedurally synthesized
   with the Web Audio API. No external image or sound files.
   ========================================================================= */

// ---------------------------------------------------------------------------
// AUDIO ENGINE
// ---------------------------------------------------------------------------
class AudioEngine {
  constructor(){
    this.ctx = null;
    this.master = null;
    this.muted = false;
    this.started = false;
    this.intensity = 0; // 0..1 drives layering
    this.bpm = 140;
    this.nextNoteTime = 0;
    this.step = 0;
    this.lookahead = 25; // ms
    this.scheduleAhead = 0.12; // s
    this.timerId = null;
    this.kernelPanicActive = false;
    this.bassPattern = [0,0,3,0, 0,5,3,0, 0,0,3,5, 3,0,0,0]; // semitone offsets over A minor-ish
    this.arpPattern  = [0,3,7,10, 7,3,0,3, 0,5,8,12, 8,5,3,0];
  }

  init(){
    if(this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.8;

    this.lowpass = this.ctx.createBiquadFilter();
    this.lowpass.type = 'lowpass';
    this.lowpass.frequency.value = 18000;
    this.lowpass.Q.value = 0.7;

    this.master.connect(this.lowpass);
    this.lowpass.connect(this.ctx.destination);

    // noise buffer for rain / hats / kick body
    const bufSize = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, bufSize, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for(let i=0;i<bufSize;i++) data[i] = Math.random()*2-1;
    this.noiseBuffer = buf;

    this.rainGain = this.ctx.createGain();
    this.rainGain.gain.value = 0.0;
    this.rainGain.connect(this.master);

    this.bassGain = this.ctx.createGain();
    this.bassGain.gain.value = 0.0;
    this.bassGain.connect(this.master);

    this.drumGain = this.ctx.createGain();
    this.drumGain.gain.value = 0.0;
    this.drumGain.connect(this.master);

    this.arpGain = this.ctx.createGain();
    this.arpGain.gain.value = 0.0;
    this.arpGain.connect(this.master);

    this.fxGain = this.ctx.createGain();
    this.fxGain.gain.value = 0.9;
    this.fxGain.connect(this.master);

    // distortion for the "drop"
    this.shaper = this.ctx.createWaveShaper();
    const curve = new Float32Array(1024);
    for(let i=0;i<1024;i++){
      const x = i/512 - 1;
      curve[i] = Math.tanh(x*6);
    }
    this.shaper.curve = curve;

    this.started = true;
  }

  resume(){ if(this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }

  setMuted(m){
    this.muted = m;
    if(this.master) this.master.gain.setTargetAtTime(m?0:0.8, this.ctx.currentTime, 0.05);
  }

  now(){ return this.ctx.currentTime; }

  // ---- utility voices ----
  noiseBurst(dest, dur=0.2, filterFreq=1200, type='lowpass', gainVal=0.6){
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const f = this.ctx.createBiquadFilter();
    f.type = type; f.frequency.value = filterFreq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gainVal, this.now());
    g.gain.exponentialRampToValueAtTime(0.001, this.now()+dur);
    src.connect(f); f.connect(g); g.connect(dest);
    src.start();
    src.stop(this.now()+dur+0.05);
    return src;
  }

  tone(freq, dur, type='sine', dest=null, gainVal=0.3, startAt=null){
    const t0 = startAt!=null ? startAt : this.now();
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gainVal, t0+0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0+dur);
    osc.connect(g); g.connect(dest||this.master);
    osc.start(t0);
    osc.stop(t0+dur+0.05);
    return osc;
  }

  // ---- one-shot SFX ----
  sfxShoot(kind){
    if(!this.ctx || this.muted) return;
    const t = this.now();
    if(kind==='ping'){
      this.tone(880+Math.random()*120, 0.05, 'square', this.fxGain, 0.05);
    } else if(kind==='pump'){
      this.noiseBurst(this.fxGain, 0.12, 2200, 'bandpass', 0.35);
      this.tone(180, 0.08, 'sawtooth', this.fxGain, 0.12);
    } else if(kind==='corrupt'){
      this.tone(120+Math.random()*40, 0.06, 'sawtooth', this.fxGain, 0.05);
    }
  }
  sfxHit(){ if(!this.ctx||this.muted) return; this.noiseBurst(this.fxGain, 0.08, 900, 'highpass', 0.25); }
  sfxPlayerHurt(){ if(!this.ctx||this.muted) return; this.tone(90,0.25,'sawtooth',this.fxGain,0.25); this.noiseBurst(this.fxGain,0.2,400,'lowpass',0.3); }
  sfxPickup(){ if(!this.ctx||this.muted) return; const t=this.now(); this.tone(660,0.09,'square',this.fxGain,0.18,t); this.tone(990,0.12,'square',this.fxGain,0.16,t+0.06); }
  sfxPortal(){ if(!this.ctx||this.muted) return; const t=this.now(); for(let i=0;i<5;i++) this.tone(220+i*140,0.5,'sine',this.fxGain,0.08,t+i*0.05); }
  sfxUltKernel(){ if(!this.ctx||this.muted) return; this.noiseBurst(this.fxGain,0.6,600,'lowpass',0.4); this.tone(50,0.7,'sine',this.fxGain,0.3); }
  sfxUltFork(){ if(!this.ctx||this.muted) return; const t=this.now(); for(let i=0;i<4;i++) this.tone(300+i*90,0.15,'square',this.fxGain,0.15,t+i*0.03); }
  sfxBossHit(){ if(!this.ctx||this.muted) return; this.tone(60,0.2,'sawtooth',this.fxGain,0.3); }
  sfxExplode(big){ if(!this.ctx||this.muted) return; this.noiseBurst(this.fxGain, big?0.9:0.3, big?400:1000,'lowpass', big?0.55:0.3); this.tone(big?40:80, big?0.9:0.25,'sine',this.fxGain,big?0.4:0.2); }

  // ---- the DROP intro ----
  playDrop(onDone){
    if(!this.ctx) { if(onDone) onDone(); return; }
    const t = this.now();
    // sub bass BRAAM
    const osc = this.ctx.createOscillator();
    osc.type='sine';
    osc.frequency.setValueAtTime(50,t);
    osc.frequency.exponentialRampToValueAtTime(38, t+1.6);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001,t);
    g.gain.exponentialRampToValueAtTime(0.6,t+0.15);
    g.gain.exponentialRampToValueAtTime(0.0001,t+1.8);
    osc.connect(this.shaper); this.shaper.connect(g); g.connect(this.master);
    osc.start(t); osc.stop(t+1.9);

    // screech
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    const nf = this.ctx.createBiquadFilter();
    nf.type='bandpass'; nf.frequency.setValueAtTime(1500,t); nf.frequency.exponentialRampToValueAtTime(6000,t+1.3);
    nf.Q.value=6;
    const ng = this.ctx.createGain();
    ng.gain.setValueAtTime(0.0001,t);
    ng.gain.exponentialRampToValueAtTime(0.5,t+0.2);
    ng.gain.exponentialRampToValueAtTime(0.0001,t+1.4);
    noise.connect(nf); nf.connect(ng); ng.connect(this.master);
    noise.start(t); noise.stop(t+1.5);

    setTimeout(()=>{ if(onDone) onDone(); }, 1900);
  }

  // rain + keyboard clacks for the pre-drop sequence
  startAmbient(){
    if(!this.ctx) return;
    this.rainSrc = this.ctx.createBufferSource();
    this.rainSrc.buffer = this.noiseBuffer;
    this.rainSrc.loop = true;
    const f = this.ctx.createBiquadFilter();
    f.type='bandpass'; f.frequency.value=1800; f.Q.value=0.6;
    this.rainSrc.connect(f); f.connect(this.rainGain);
    this.rainGain.gain.setTargetAtTime(0.09, this.now(), 0.6);
    this.rainSrc.start();

    // fan hum
    this.fanOsc = this.ctx.createOscillator();
    this.fanOsc.type='sine'; this.fanOsc.frequency.value=63;
    this.fanGain = this.ctx.createGain(); this.fanGain.gain.value=0.02;
    this.fanOsc.connect(this.fanGain); this.fanGain.connect(this.master);
    this.fanOsc.start();

    this.clackRate = 260;
    this._clackLoop();
  }
  _clackLoop(){
    if(!this.ctx) return;
    this.noiseBurst(this.rainGain, 0.03, 3500, 'highpass', 0.18);
    this.clackTimer = setTimeout(()=>this._clackLoop(), this.clackRate + Math.random()*40);
  }
  accelerateClacks(){
    const start = Date.now();
    const dur = 2200;
    const tick = ()=>{
      const p = Math.min(1,(Date.now()-start)/dur);
      this.clackRate = 260 - p*220;
      if(p<1) requestAnimationFrame(tick);
    };
    tick();
  }
  stopAmbient(fadeTime=0.5){
    if(this.clackTimer) clearTimeout(this.clackTimer);
    if(this.rainGain) this.rainGain.gain.setTargetAtTime(0, this.now(), fadeTime);
    setTimeout(()=>{ try{this.rainSrc.stop();}catch(e){} }, fadeTime*1000+200);
  }
  fanOnly(){
    if(this.clackTimer) clearTimeout(this.clackTimer);
    if(this.rainGain) this.rainGain.gain.setTargetAtTime(0.06, this.now(), 1.2);
  }

  // ---- adaptive scheduler ----
  startMusic(){
    if(this.musicRunning) return;
    this.musicRunning = true;
    this.nextNoteTime = this.now()+0.1;
    this.step = 0;
    this.bassGain.gain.setTargetAtTime(0.22, this.now(), 1.0);
    this._schedulerLoop();
  }
  stopMusic(){
    this.musicRunning = false;
    if(this.schedTimer) clearTimeout(this.schedTimer);
    this.bassGain.gain.setTargetAtTime(0,this.now(),0.4);
    this.drumGain.gain.setTargetAtTime(0,this.now(),0.4);
    this.arpGain.gain.setTargetAtTime(0,this.now(),0.4);
  }
  setIntensity(v){ this.intensity = Math.max(0,Math.min(1,v)); }

  _schedulerLoop(){
    if(!this.musicRunning) return;
    while(this.nextNoteTime < this.now()+this.scheduleAhead){
      this._scheduleStep(this.step, this.nextNoteTime);
      const secPerBeat = 60.0/this.bpm/4; // 16th notes
      this.nextNoteTime += secPerBeat;
      this.step = (this.step+1)%16;
    }
    this.schedTimer = setTimeout(()=>this._schedulerLoop(), this.lookahead);
  }

  _scheduleStep(step, t){
    const root = 55; // A1
    // bass every 4th 16th (quarter notes) with occasional 8th push
    if(step%4===0 || (step%4===2 && this.intensity>0.4)){
      const semis = this.bassPattern[step];
      const freq = root*Math.pow(2, semis/12);
      const osc = this.ctx.createOscillator();
      osc.type='sawtooth';
      osc.frequency.setValueAtTime(freq,t);
      const filt = this.ctx.createBiquadFilter();
      filt.type='lowpass'; filt.frequency.setValueAtTime(400+this.intensity*900,t);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.0001,t);
      g.gain.exponentialRampToValueAtTime(0.5,t+0.02);
      g.gain.exponentialRampToValueAtTime(0.0001,t+0.22);
      osc.connect(this.shaper); this.shaper.connect(filt); filt.connect(g); g.connect(this.bassGain);
      osc.start(t); osc.stop(t+0.25);
    }
    // drums scale in with intensity
    if(this.intensity>0.15){
      if(step%4===0){ // kick
        const g=this.ctx.createGain();
        g.gain.setValueAtTime(0.7*this.intensity,t);
        g.gain.exponentialRampToValueAtTime(0.001,t+0.18);
        this.noiseBurst(this.drumGain,0.15,120,'lowpass',0.5*this.intensity);
        const osc=this.ctx.createOscillator(); osc.type='sine';
        osc.frequency.setValueAtTime(150,t); osc.frequency.exponentialRampToValueAtTime(40,t+0.15);
        osc.connect(g); g.connect(this.drumGain); osc.start(t); osc.stop(t+0.2);
      }
      if(step%4===2 && this.intensity>0.35){ // snare-ish
        this.noiseBurst(this.drumGain,0.12,1800,'bandpass',0.35*this.intensity);
      }
      if(this.intensity>0.5 && step%2===1){ // hats
        this.noiseBurst(this.drumGain,0.04,7000,'highpass',0.12*this.intensity);
      }
    }
    // arp layer at high intensity
    if(this.intensity>0.6 && step%2===0){
      const semis = this.arpPattern[step];
      const freq = root*4*Math.pow(2, semis/12);
      const osc=this.ctx.createOscillator();
      osc.type='square';
      osc.frequency.setValueAtTime(freq,t);
      const g=this.ctx.createGain();
      g.gain.setValueAtTime(0.0001,t);
      g.gain.exponentialRampToValueAtTime(0.15*(this.intensity-0.5)*2,t+0.01);
      g.gain.exponentialRampToValueAtTime(0.0001,t+0.14);
      osc.connect(g); g.connect(this.arpGain);
      osc.start(t); osc.stop(t+0.16);
    }
  }

  kernelPanicFX(on){
    this.kernelPanicActive = on;
    const t = this.now();
    if(on){
      this.lowpass.frequency.cancelScheduledValues(t);
      this.lowpass.frequency.setValueAtTime(this.lowpass.frequency.value,t);
      this.lowpass.frequency.linearRampToValueAtTime(280,t+0.15);
      this.bpm = 70;
    } else {
      this.lowpass.frequency.cancelScheduledValues(t);
      this.lowpass.frequency.setValueAtTime(this.lowpass.frequency.value,t);
      this.lowpass.frequency.linearRampToValueAtTime(18000,t+0.12);
      this.noiseBurst(this.fxGain,0.15,4000,'highpass',0.4);
      this.bpm = 140;
    }
  }

  playVictory(){
    this.stopMusic();
    const t = this.now();
    const chord = [220,277.2,329.6,440]; // Am-ish chord
    chord.forEach((f,i)=>{
      const osc=this.ctx.createOscillator(); osc.type='sine';
      osc.frequency.value=f;
      const g=this.ctx.createGain();
      g.gain.setValueAtTime(0.0001,t);
      g.gain.exponentialRampToValueAtTime(0.18,t+0.05);
      g.gain.exponentialRampToValueAtTime(0.0001,t+3.2);
      osc.connect(g); g.connect(this.master);
      osc.start(t); osc.stop(t+3.3);
    });
  }
}

// ---------------------------------------------------------------------------
// MAZE GENERATION (randomized DFS carve, grid based)
// ---------------------------------------------------------------------------
function generateMaze(cols, rows, courtyardChance=0.12){
  // grid[y][x] = true means WALL
  const grid = [];
  for(let y=0;y<rows;y++){ grid.push(new Array(cols).fill(true)); }

  function carve(cx,cy){
    grid[cy][cx]=false;
    const dirs = [[0,-2],[0,2],[-2,0],[2,0]];
    for(let i=dirs.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [dirs[i],dirs[j]]=[dirs[j],dirs[i]]; }
    for(const [dx,dy] of dirs){
      const nx=cx+dx, ny=cy+dy;
      if(nx>0 && nx<cols-1 && ny>0 && ny<rows-1 && grid[ny][nx]){
        grid[cy+dy/2][cx+dx/2]=false;
        carve(nx,ny);
      }
    }
  }
  carve(1,1);

  // open up courtyards - randomly clear small blocks
  for(let y=1;y<rows-2;y++){
    for(let x=1;x<cols-2;x++){
      if(Math.random()<courtyardChance){
        grid[y][x]=false; grid[y+1][x]=false; grid[y][x+1]=false; grid[y+1][x+1]=false;
      }
    }
  }
  // ensure border walls
  for(let x=0;x<cols;x++){ grid[0][x]=true; grid[rows-1][x]=true; }
  for(let y=0;y<rows;y++){ grid[y][0]=true; grid[y][cols-1]=true; }
  return grid;
}

// ---------------------------------------------------------------------------
// GAME
// ---------------------------------------------------------------------------
const CELL = 42;

const STAGES = [
  {name:'LOCAL HOST', cols:19, rows:15, enemies:6, boss:null, theme:'cyan'},
  {name:'DATA CUBICLES', cols:21, rows:15, enemies:8, boss:null, theme:'cyan'},
  {name:'THE REGISTRY', cols:17, rows:13, enemies:3, boss:'stackoverflow', theme:'magenta'},
  {name:'PACKET RELAY', cols:21, rows:17, enemies:10, boss:null, theme:'cyan'},
  {name:'CACHE VAULT', cols:23, rows:17, enemies:11, boss:null, theme:'green'},
  {name:'PROCESS FORGE', cols:23, rows:17, enemies:12, boss:null, theme:'amber'},
  {name:'FIREWALL CITADEL', cols:19, rows:15, enemies:6, boss:'firewall', theme:'magenta'},
  {name:'RUNTIME DEPTHS', cols:25, rows:19, enemies:14, boss:null, theme:'cyan'},
  {name:'KERNEL SPACE', cols:25, rows:19, enemies:16, boss:null, theme:'green'},
  {name:'ROOT DIRECTORY', cols:21, rows:17, enemies:2, boss:'rootuser', theme:'magenta'},
];

const GLITCHES = {
  OVERCLOCK_VCORE:{
    name:'OVERCLOCK_VCORE',
    plus:'+100% fire rate / +40% move speed',
    minus:'+30% hitbox size',
    apply:(p)=>{ p.fireRateMult*=2.0; p.speedMult*=1.4; p.hitboxMult*=1.3; }
  },
  SWAP_PARTITION:{
    name:'SWAP_PARTITION',
    plus:'+100% max health',
    minus:'-25% move speed',
    apply:(p)=>{ p.maxHealth*=2; p.health=p.maxHealth; p.speedMult*=0.75; }
  },
  DATA_STRIPING:{
    name:'DATA_STRIPING',
    plus:'x2 damage output',
    minus:'x2 damage taken',
    apply:(p)=>{ p.damageMult*=2; p.vulnMult*=2; }
  }
};

const WEAPONS = [
  {key:'PING_FLOOD', fireDelay:0.09, dmg:5, spread:0.05, speed:640, count:1, kind:'ping', color:'#28f6ff', beam:false},
  {key:'STACK_PUMP', fireDelay:0.55, dmg:9, spread:0.42, speed:520, count:6, kind:'pump', color:'#ff2fd0', beam:false, knockback:260},
  {key:'MEM_CORRUPT', fireDelay:0.02, dmg:0.9, spread:0.03, speed:0, count:1, kind:'corrupt', color:'#39ff88', beam:true, range:230, dot:true},
];

function dist2(ax,ay,bx,by){ const dx=ax-bx, dy=ay-by; return dx*dx+dy*dy; }
function len(x,y){ return Math.sqrt(x*x+y*y); }
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }

class Game {
  constructor(){
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');
    this.audio = new AudioEngine();
    this.resize();
    window.addEventListener('resize', ()=>this.resize());

    this.keys = {};
    this.mouse = {x:0,y:0,down:false};
    this.touchMove = {active:false,x:0,y:0,dx:0,dy:0};
    this.touchFire = false;

    this.state = 'menu'; // menu, boot, playing, glitchpick, paused, gameover, victory
    this.stageIndex = 0;
    this.score = 0;
    this.time = 0;
    this.particles = [];
    this.floaters = [];
    this.usedGlitches = new Set();

    this.bindInput();
    this.bindUI();
    requestAnimationFrame((t)=>this.loop(t));
  }

  resize(){
    const dpr = Math.min(window.devicePixelRatio||1, 2);
    this.canvas.width = window.innerWidth*dpr;
    this.canvas.height = window.innerHeight*dpr;
    this.canvas.style.width = window.innerWidth+'px';
    this.canvas.style.height = window.innerHeight+'px';
    this.ctx.setTransform(dpr,0,0,dpr,0,0);
    this.vw = window.innerWidth; this.vh = window.innerHeight;
  }

  bindInput(){
    window.addEventListener('keydown', (e)=>{
      this.keys[e.code]=true;
      if(this.state==='playing'){
        if(e.code==='Digit1') this.switchWeapon(0);
        if(e.code==='Digit2') this.switchWeapon(1);
        if(e.code==='Digit3') this.switchWeapon(2);
        if(e.code==='Space'){ e.preventDefault(); this.tryUlt('kernel'); }
        if(e.code==='KeyF'){ this.tryUlt('fork'); }
      }
    });
    window.addEventListener('keyup', (e)=>{ this.keys[e.code]=false; });
    this.canvas.addEventListener('mousemove', (e)=>{ this.mouse.x=e.clientX; this.mouse.y=e.clientY; });
    this.canvas.addEventListener('mousedown', (e)=>{ this.mouse.down=true; });
    window.addEventListener('mouseup', ()=>{ this.mouse.down=false; });

    // touch controls
    const stick = document.getElementById('moveStick');
    const nub = document.getElementById('moveNub');
    let stickId=null, stickOrigin={x:0,y:0};
    stick.addEventListener('touchstart', (e)=>{
      const t=e.changedTouches[0]; stickId=t.identifier;
      const r=stick.getBoundingClientRect(); stickOrigin={x:r.left+r.width/2,y:r.top+r.height/2};
      this.touchMove.active=true; e.preventDefault();
    });
    window.addEventListener('touchmove', (e)=>{
      for(const t of e.changedTouches){
        if(t.identifier===stickId){
          let dx=t.clientX-stickOrigin.x, dy=t.clientY-stickOrigin.y;
          const m=len(dx,dy); const max=48;
          if(m>max){ dx=dx/m*max; dy=dy/m*max; }
          nub.style.left=(32+dx)+'px'; nub.style.top=(32+dy)+'px';
          this.touchMove.dx=dx/max; this.touchMove.dy=dy/max;
        }
      }
    },{passive:false});
    window.addEventListener('touchend',(e)=>{
      for(const t of e.changedTouches){
        if(t.identifier===stickId){ stickId=null; this.touchMove.active=false; this.touchMove.dx=0; this.touchMove.dy=0; nub.style.left='32px'; nub.style.top='32px'; }
      }
    });
    const fireBtn=document.getElementById('fireBtn');
    fireBtn.addEventListener('touchstart',(e)=>{this.touchFire=true;e.preventDefault();});
    fireBtn.addEventListener('touchend',(e)=>{this.touchFire=false;});
    document.getElementById('ultBtn1').addEventListener('touchstart',(e)=>{this.tryUlt('kernel');e.preventDefault();});
    document.getElementById('ultBtn2').addEventListener('touchstart',(e)=>{this.tryUlt('fork');e.preventDefault();});
    document.querySelectorAll('#wswitch div').forEach(el=>{
      el.addEventListener('touchstart',(e)=>{ this.switchWeapon(parseInt(el.dataset.w)); e.preventDefault(); });
    });
    // for touch aim: use last drag on canvas as aim direction toward player facing = movement dir if no separate aim stick (simplify: aim = move dir, autoaim nearest enemy otherwise)
  }

  bindUI(){
    document.getElementById('startBtn').addEventListener('click', ()=>{
      this.audio.init(); this.audio.resume();
      document.getElementById('menuScreen').classList.add('hidden');
      this.startBoot();
    });
    document.getElementById('muteBtn').addEventListener('click', (e)=>{
      this.audio.init();
      this.muted = !this.muted;
      this.audio.setMuted(this.muted);
      e.target.textContent = 'SOUND: '+(this.muted?'OFF':'ON');
    });
    document.getElementById('retryBtn').addEventListener('click', ()=>{
      document.getElementById('endScreen').classList.add('hidden');
      this.resetRun();
      this.startBoot();
    });
  }

  startBoot(){
    this.state='boot';
    document.getElementById('bootScreen').classList.remove('hidden');
    const introText = document.getElementById('introText');
    introText.innerHTML='';
    this.audio.startAmbient();
    const lines = [
      {t:'> connecting to remote host...', d:900},
      {t:'> injecting process 0x00FF into runtime', d:1400},
      {t:'> patching memory boundaries', d:1200, accel:true},
      {t:'> ACCESS ANOMALY DETECTED', d:900, cls:'accent'},
    ];
    let delay=300;
    lines.forEach((line,i)=>{
      setTimeout(()=>{
        const div=document.createElement('div');
        div.className='introline'+(line.cls?(' '+line.cls):'');
        div.style.color = line.cls==='accent' ? 'var(--magenta)' : '#c9d2f2';
        div.textContent=line.t;
        introText.appendChild(div);
        requestAnimationFrame(()=>div.classList.add('show'));
        if(line.accel) this.audio.accelerateClacks();
      }, delay);
      delay+=line.d;
    });
    setTimeout(()=>{
      // THE DROP
      introText.innerHTML='';
      this.audio.stopAmbient(0.05);
      this.audio.playDrop(()=>{
        this.audio.fanOnly();
        const div=document.createElement('div');
        div.className='introline';
        div.style.color='var(--cyan)';
        div.style.fontSize='18px';
        div.style.textAlign='center';
        div.textContent='you are no longer outside the machine.';
        introText.appendChild(div);
        requestAnimationFrame(()=>div.classList.add('show'));
        setTimeout(()=>{
          const div2=document.createElement('div');
          div2.className='introline';
          div2.style.color='#fff';
          div2.style.fontSize='22px';
          div2.style.textAlign='center';
          div2.style.marginTop='14px';
          div2.textContent='you are a process running inside it.';
          introText.appendChild(div2);
          requestAnimationFrame(()=>div2.classList.add('show'));
          setTimeout(()=>{
            document.getElementById('bootScreen').classList.add('hidden');
            this.audio.stopAmbient(0.3);
            this.resetRun();
            this.loadStage(0);
          }, 1700);
        }, 900);
      });
    }, delay+300);
  }

  resetRun(){
    this.stageIndex=0;
    this.score=0;
    this.usedGlitches.clear();
    this.player = {
      x:0,y:0, vx:0,vy:0, r:13,
      health:100, maxHealth:100,
      speedMult:1, damageMult:1, vulnMult:1, fireRateMult:1, hitboxMult:1,
      weaponIdx:0, cooldown:0,
      angle:0,
      ultKernelCd:0, ultKernelMax:20,
      ultForkCd:0, ultForkMax:20,
      forkActiveT:0,
      invuln:0,
    };
    document.getElementById('glitchList').textContent='none';
  }

  loadStage(idx){
    this.stageIndex=idx;
    const cfg = STAGES[idx];
    this.state='playing';
    document.getElementById('hud').classList.remove('hidden');
    document.getElementById('stageNum').textContent = (idx+1)+' / 10';
    document.getElementById('stageName').textContent = cfg.name;
    document.getElementById('bossBarWrap').classList.toggle('hidden', !cfg.boss);
    this.showCenterMsg('STAGE '+(idx+1)+' — '+cfg.name, 1800);

    const cols = cfg.cols|1, rows=cfg.rows|1; // ensure odd
    this.grid = generateMaze(cols, rows, cfg.boss?0.03:0.13);
    this.cols=cols; this.rows=rows;
    this.mazeW = cols*CELL; this.mazeH = rows*CELL;

    // find open cells
    const openCells=[];
    for(let y=1;y<rows-1;y++) for(let x=1;x<cols-1;x++) if(!this.grid[y][x]) openCells.push([x,y]);

    // place player near a corner-ish open cell
    openCells.sort((a,b)=> (a[0]+a[1]) - (b[0]+b[1]) );
    const startCell = openCells[Math.floor(openCells.length*0.02)] || openCells[0];
    this.player.x = startCell[0]*CELL+CELL/2;
    this.player.y = startCell[1]*CELL+CELL/2;
    this.player.invuln = 1.2;

    // gateway portal placed far from player
    let best=openCells[openCells.length-1], bestD=-1;
    for(const c of openCells){ const d=dist2(c[0],c[1],startCell[0],startCell[1]); if(d>bestD){bestD=d; best=c;} }
    this.portal = {x:best[0]*CELL+CELL/2, y:best[1]*CELL+CELL/2, active:!cfg.boss};

    // enemies
    this.enemies=[];
    this.projectiles=[];
    this.pickups=[];
    this.boss=null;

    const farCells = openCells.filter(c=>dist2(c[0],c[1],startCell[0],startCell[1])>16);
    for(let i=0;i<cfg.enemies;i++){
      const c = farCells[Math.floor(Math.random()*farCells.length)];
      this.spawnEnemy(c[0]*CELL+CELL/2, c[1]*CELL+CELL/2, cfg.boss==='firewall' && i%3===0 ? 'turret':'grunt');
    }
    // source code caches (skip on pure boss arenas mostly, but allow 1)
    const cacheCount = cfg.boss ? 1 : (2+Math.floor(Math.random()*2));
    for(let i=0;i<cacheCount;i++){
      const c = farCells[Math.floor(Math.random()*farCells.length)];
      this.pickups.push({x:c[0]*CELL+CELL/2,y:c[1]*CELL+CELL/2, r:9, t:0});
    }

    if(cfg.boss){
      this.spawnBoss(cfg.boss, this.portal.x, this.portal.y);
    }

    this.camera={x:this.player.x,y:this.player.y};
    this.audio.startMusic();
    this.audio.setIntensity(0.1);
  }

  spawnEnemy(x,y,type='grunt'){
    const base = {
      x,y, r:12, type,
      health: type==='turret'?26:16,
      maxHealth: type==='turret'?26:16,
      speed: type==='turret'?0:80+Math.random()*40,
      fireCd: Math.random()*1.5,
      vx:0,vy:0,
      alive:true,
      hitFlash:0,
    };
    this.enemies.push(base);
  }

  spawnBoss(kind, x, y){
    const bosses = {
      stackoverflow:{name:'STACK_OVERFLOW_CORE', health:220, r:34, speed:40, phase:0},
      firewall:{name:'FIREWALL CITADEL', health:0, r:0, speed:0, isEnvironment:true}, // handled via turrets
      rootuser:{name:'THE ROOT USER', health:340, r:30, speed:70, phase:0, disableT:0},
    };
    const b = Object.assign({x,y,alive:true,hitFlash:0,vx:0,vy:0,fireCd:1,t:0}, bosses[kind]);
    b.kind=kind;
    b.maxHealth = b.health;
    if(!b.isEnvironment){
      this.boss=b;
      document.getElementById('bossName').textContent = b.name;
      document.getElementById('bossBarWrap').classList.remove('hidden');
    } else {
      document.getElementById('bossBarWrap').classList.add('hidden');
      this.portal.active = true; // firewall stage: survive/clear turrets then exit
    }
  }

  switchWeapon(i){
    this.player.weaponIdx=i;
    document.querySelectorAll('.wslot').forEach((el,idx)=>el.classList.toggle('active', idx===i));
  }

  tryUlt(which){
    const p=this.player;
    if(which==='kernel' && p.ultKernelCd<=0){
      p.ultKernelCd=p.ultKernelMax;
      this.kernelPanicT = 4;
      this.audio.sfxUltKernel();
      this.audio.kernelPanicFX(true);
      this.showCenterMsg('KERNEL_PANIC', 900);
      this.spawnShockwave(p.x,p.y);
    } else if(which==='fork' && p.ultForkCd<=0){
      p.ultForkCd=p.ultForkMax;
      p.forkActiveT=5;
      this.audio.sfxUltFork();
      this.showCenterMsg('FORK_BOMB ARMED', 900);
    }
  }

  spawnShockwave(x,y){
    for(let i=0;i<26;i++){
      const a=(i/26)*Math.PI*2;
      this.particles.push({x,y,vx:Math.cos(a)*260,vy:Math.sin(a)*260,life:0.5,maxLife:0.5,color:'#28f6ff',r:3});
    }
  }

  showCenterMsg(txt, dur){
    const el=document.getElementById('centerMsg');
    el.textContent=txt;
    el.classList.add('show');
    clearTimeout(this._cmTimer);
    this._cmTimer=setTimeout(()=>el.classList.remove('show'), dur);
  }

  // ---------------- collision helpers ----------------
  isWall(px,py){
    const cx=Math.floor(px/CELL), cy=Math.floor(py/CELL);
    if(cx<0||cy<0||cx>=this.cols||cy>=this.rows) return true;
    return this.grid[cy][cx];
  }
  circleWallCollide(x,y,r){
    // sample a few points around circle
    const pts=[[x-r,y],[x+r,y],[x,y-r],[x,y+r],[x,y]];
    for(const [px,py] of pts) if(this.isWall(px,py)) return true;
    return false;
  }
  moveWithCollision(ent, dx, dy){
    const r=ent.r;
    let nx=ent.x+dx;
    if(!this.circleWallCollide(nx,ent.y,r)) ent.x=nx;
    let ny=ent.y+dy;
    if(!this.circleWallCollide(ent.x,ny,r)) ent.y=ny;
  }

  // ---------------- update ----------------
  loop(ts){
    if(!this._last) this._last=ts;
    let dt=(ts-this._last)/1000;
    this._last=ts;
    dt=Math.min(dt,0.05);
    if(this.state==='playing') this.update(dt);
    this.render();
    requestAnimationFrame((t)=>this.loop(t));
  }

  update(dt){
    this.time+=dt;
    const p=this.player;

    // cooldowns
    p.cooldown-=dt;
    p.ultKernelCd=Math.max(0,p.ultKernelCd-dt);
    p.ultForkCd=Math.max(0,p.ultForkCd-dt);
    p.invuln=Math.max(0,p.invuln-dt);
    if(p.forkActiveT>0) p.forkActiveT-=dt;

    let frozen=false;
    if(this.kernelPanicT>0){
      this.kernelPanicT-=dt;
      frozen=true;
      if(this.kernelPanicT<=0){ this.audio.kernelPanicFX(false); }
    }

    // movement input
    let mx=0,my=0;
    if(this.keys['KeyW']||this.keys['ArrowUp']) my-=1;
    if(this.keys['KeyS']||this.keys['ArrowDown']) my+=1;
    if(this.keys['KeyA']||this.keys['ArrowLeft']) mx-=1;
    if(this.keys['KeyD']||this.keys['ArrowRight']) mx+=1;
    if(this.touchMove.active){ mx=this.touchMove.dx; my=this.touchMove.dy; }
    const mlen=len(mx,my);
    if(mlen>0.01){ mx/=Math.max(mlen,1); my/=Math.max(mlen,1); }
    const speed=220*p.speedMult;
    this.moveWithCollision(p, mx*speed*dt, my*speed*dt);

    // aim
    if(!this.isTouch()){
      const wx = this.mouse.x - this.vw/2 + this.camera.x;
      const wy = this.mouse.y - this.vh/2 + this.camera.y;
      p.angle = Math.atan2(wy-p.y, wx-p.x);
    } else if(mlen>0.05){
      p.angle = Math.atan2(my,mx);
    } else {
      // autoaim nearest enemy for touch
      const n=this.nearestEnemy();
      if(n) p.angle = Math.atan2(n.y-p.y, n.x-p.x);
    }

    // fire
    const firing = this.mouse.down || this.touchFire;
    const wep = WEAPONS[p.weaponIdx];
    if(firing && p.cooldown<=0){
      p.cooldown = wep.fireDelay/p.fireRateMult;
      this.fireWeapon(wep);
    }

    // camera follow
    this.camera.x += (p.x-this.camera.x)*Math.min(1,10*dt);
    this.camera.y += (p.y-this.camera.y)*Math.min(1,10*dt);

    if(!frozen){
      this.updateEnemies(dt);
      if(this.boss) this.updateBoss(dt);
    }
    this.updateProjectiles(dt, frozen);
    this.updateParticles(dt);
    this.updatePickups(dt);
    this.updatePortal(dt);

    // intensity for music
    let nearby=0;
    for(const e of this.enemies) if(e.alive && dist2(e.x,e.y,p.x,p.y)<420*420) nearby++;
    const intensity = clamp(nearby/8 + (this.boss?0.5:0), 0, 1);
    this.audio.setIntensity(intensity);

    // death
    if(p.health<=0){
      this.onGameOver();
    }

    this.updateHUD();
  }

  isTouch(){ return this.touchMove.active || document.getElementById('touchControls').style.display==='block' || window.matchMedia('(pointer:coarse)').matches; }

  nearestEnemy(){
    let best=null,bd=Infinity;
    for(const e of this.enemies){ if(!e.alive) continue; const d=dist2(e.x,e.y,this.player.x,this.player.y); if(d<bd){bd=d;best=e;} }
    if(this.boss && this.boss.alive){ const d=dist2(this.boss.x,this.boss.y,this.player.x,this.player.y); if(d<bd) best=this.boss; }
    return best;
  }

  fireWeapon(wep){
    const p=this.player;
    this.audio.sfxShoot(wep.kind);
    if(wep.beam){
      // instant hit-scan short beam, apply DOT to whatever's in a narrow cone within range
      const dmg = wep.dmg*p.damageMult;
      for(const e of this.enemies){
        if(!e.alive) continue;
        const d=len(e.x-p.x,e.y-p.y);
        if(d<wep.range){
          const ang=Math.atan2(e.y-p.y,e.x-p.x);
          let diff=Math.abs(ang-p.angle); if(diff>Math.PI) diff=2*Math.PI-diff;
          if(diff<0.3){ this.damageEnemy(e,dmg); }
        }
      }
      if(this.boss && this.boss.alive){
        const d=len(this.boss.x-p.x,this.boss.y-p.y);
        if(d<wep.range+this.boss.r){
          const ang=Math.atan2(this.boss.y-p.y,this.boss.x-p.x);
          let diff=Math.abs(ang-p.angle); if(diff>Math.PI) diff=2*Math.PI-diff;
          if(diff<0.35) this.damageBoss(dmg);
        }
      }
      this.particles.push({beam:true,x:p.x,y:p.y,angle:p.angle,range:wep.range,life:0.08,maxLife:0.08,color:wep.color});
      return;
    }
    const count=wep.count;
    for(let i=0;i<count;i++){
      const spread=(Math.random()-0.5)*wep.spread + (count>1?(i/(count-1)-0.5)*wep.spread*2:0);
      const a=p.angle+spread;
      this.projectiles.push({
        x:p.x+Math.cos(p.angle)*18, y:p.y+Math.sin(p.angle)*18,
        vx:Math.cos(a)*wep.speed, vy:Math.sin(a)*wep.speed,
        dmg:wep.dmg*p.damageMult, r:wep.kind==='pump'?5:3,
        color:wep.color, life:1.4, friendly:true,
        knockback:wep.knockback||0,
        canSplit: p.forkActiveT>0,
      });
    }
  }

  updateEnemies(dt){
    const p=this.player;
    for(const e of this.enemies){
      if(!e.alive) continue;
      e.hitFlash=Math.max(0,e.hitFlash-dt);
      if(e.type==='grunt'){
        const dx=p.x-e.x, dy=p.y-e.y, d=len(dx,dy)||1;
        const spd=e.speed;
        this.moveWithCollision(e, dx/d*spd*dt, dy/d*spd*dt);
        e.fireCd-=dt;
        if(e.fireCd<=0 && d<380){
          e.fireCd=1.3+Math.random()*0.8;
          const a=Math.atan2(dy,dx);
          this.projectiles.push({x:e.x,y:e.y,vx:Math.cos(a)*220,vy:Math.sin(a)*220,dmg:8,r:4,color:'#ff5060',life:2.5,friendly:false});
          this.audio.sfxShoot('ping');
        }
      } else if(e.type==='turret'){
        e.fireCd-=dt;
        const dx=p.x-e.x, dy=p.y-e.y, d=len(dx,dy)||1;
        if(e.fireCd<=0 && d<520){
          e.fireCd=1.6;
          const a=Math.atan2(dy,dx);
          this.projectiles.push({x:e.x,y:e.y,vx:Math.cos(a)*260,vy:Math.sin(a)*260,dmg:10,r:4,color:'#ffb020',life:2.5,friendly:false});
          this.audio.sfxShoot('ping');
        }
      }
      // contact damage
      if(dist2(e.x,e.y,p.x,p.y) < (e.r+p.r*p.hitboxMult)*(e.r+p.r*p.hitboxMult)){
        this.hurtPlayer(6*dt*p.vulnMult*10*dt); // small continuous chip - scaled down below
      }
    }
    this.enemies=this.enemies.filter(e=>e.alive || e.deathTimer===undefined);
  }

  updateBoss(dt){
    const b=this.boss, p=this.player;
    if(!b.alive) return;
    b.t+=dt;
    b.hitFlash=Math.max(0,b.hitFlash-dt);
    if(b.kind==='stackoverflow'){
      // gravity well pull + shifting maze feel via pulsing radius; simple chase + pulse damage rings
      const dx=p.x-b.x, dy=p.y-b.y, d=len(dx,dy)||1;
      this.moveWithCollision(b, dx/d*b.speed*dt, dy/d*b.speed*dt);
      // gravity pull on player
      if(d<260){
        const pull=140*dt*(1-d/260);
        p.x += dx/d*pull; p.y += dy/d*pull;
      }
      b.fireCd-=dt;
      if(b.fireCd<=0){
        b.fireCd=1.8;
        for(let i=0;i<10;i++){
          const a=(i/10)*Math.PI*2;
          this.projectiles.push({x:b.x,y:b.y,vx:Math.cos(a)*180,vy:Math.sin(a)*180,dmg:12,r:5,color:'#ff2fd0',life:3,friendly:false});
        }
        this.audio.sfxExplode(false);
      }
    } else if(b.kind==='rootuser'){
      const dx=p.x-b.x, dy=p.y-b.y, d=len(dx,dy)||1;
      this.moveWithCollision(b, dx/d*b.speed*dt, dy/d*b.speed*dt);
      b.fireCd-=dt;
      if(b.fireCd<=0){
        b.fireCd=1.3;
        const a=Math.atan2(dy,dx);
        for(let s=-2;s<=2;s++){
          const aa=a+s*0.16;
          this.projectiles.push({x:b.x,y:b.y,vx:Math.cos(aa)*260,vy:Math.sin(aa)*260,dmg:11,r:4,color:'#ff2fd0',life:2.5,friendly:false});
        }
        this.audio.sfxShoot('pump');
      }
      // periodically disable weapons (raw input state)
      b.disableT-=dt;
      if(b.disableT<=0){
        b.disableT = 6+Math.random()*3;
        this.disabledWeaponsT = 2.2;
        this.showCenterMsg('WEAPONS DISABLED', 1000);
      }
    }
    if(this.disabledWeaponsT>0) this.disabledWeaponsT-=dt;
    // contact damage
    if(dist2(b.x,b.y,p.x,p.y) < (b.r+p.r*p.hitboxMult)*(b.r+p.r*p.hitboxMult)){
      this.hurtPlayer(18*dt);
    }
  }

  updateProjectiles(dt, frozen){
    const p=this.player;
    for(const pr of this.projectiles){
      if(pr.life<=0) continue;
      if(frozen && !pr.friendly){ continue; } // enemy shots freeze; player shots keep moving for satisfying panic use
      pr.x+=pr.vx*dt; pr.y+=pr.vy*dt; pr.life-=dt;
      if(this.isWall(pr.x,pr.y)){
        if(pr.canSplit && pr.friendly){
          pr.life=0;
          for(let i=0;i<2;i++){
            const a=Math.random()*Math.PI*2;
            this.projectiles.push({x:pr.x,y:pr.y,vx:Math.cos(a)*300,vy:Math.sin(a)*300,dmg:pr.dmg*0.6,r:pr.r,color:pr.color,life:0.8,friendly:true,canSplit:false});
          }
        } else {
          pr.life=0;
        }
        continue;
      }
      if(pr.friendly){
        for(const e of this.enemies){
          if(!e.alive) continue;
          if(dist2(pr.x,pr.y,e.x,e.y)<(pr.r+e.r)*(pr.r+e.r)){
            this.damageEnemy(e,pr.dmg);
            if(pr.knockback){ const a=Math.atan2(e.y-pr.y,e.x-pr.x); e.vx=Math.cos(a)*pr.knockback; e.vy=Math.sin(a)*pr.knockback; this.moveWithCollision(e,e.vx*0.05,e.vy*0.05); }
            pr.life=0; break;
          }
        }
        if(pr.life>0 && this.boss && this.boss.alive && dist2(pr.x,pr.y,this.boss.x,this.boss.y)<(pr.r+this.boss.r)*(pr.r+this.boss.r)){
          this.damageBoss(pr.dmg);
          pr.life=0;
        }
      } else {
        if(dist2(pr.x,pr.y,p.x,p.y)<(pr.r+p.r*p.hitboxMult)*(pr.r+p.r*p.hitboxMult)){
          this.hurtPlayer(pr.dmg);
          pr.life=0;
        }
      }
    }
    this.projectiles=this.projectiles.filter(pr=>pr.life>0);
  }

  damageEnemy(e,dmg){
    e.health-=dmg; e.hitFlash=0.12;
    this.audio.sfxHit();
    this.floaters.push({x:e.x,y:e.y-14,txt:Math.round(dmg).toString(),life:0.5,maxLife:0.5,color:'#fff'});
    if(e.health<=0 && e.alive){
      e.alive=false;
      this.score+=25;
      this.audio.sfxExplode(false);
      this.explode(e.x,e.y,'#ff5060');
    }
  }
  damageBoss(dmg){
    const b=this.boss;
    b.health-=dmg; b.hitFlash=0.12;
    this.audio.sfxBossHit();
    this.floaters.push({x:b.x,y:b.y-b.r-10,txt:Math.round(dmg).toString(),life:0.5,maxLife:0.5,color:'#ff2fd0'});
    if(b.health<=0 && b.alive){
      b.alive=false;
      this.score+=500;
      this.audio.sfxExplode(true);
      this.explode(b.x,b.y,'#ff2fd0',40);
      this.portal.active=true;
      this.showCenterMsg('BOSS PURGED — GATEWAY OPEN', 2000);
      document.getElementById('bossBarWrap').classList.add('hidden');
    }
  }

  explode(x,y,color,n=16){
    for(let i=0;i<n;i++){
      const a=Math.random()*Math.PI*2, sp=80+Math.random()*220;
      this.particles.push({x,y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:0.5+Math.random()*0.4,maxLife:0.9,color,r:2+Math.random()*3});
    }
  }

  hurtPlayer(dmg){
    const p=this.player;
    if(p.invuln>0) return;
    dmg*=p.vulnMult;
    p.health-=dmg;
    p.invuln=0.35;
    this.audio.sfxPlayerHurt();
  }

  updateParticles(dt){
    for(const pt of this.particles){
      pt.life-=dt;
      if(pt.beam) continue;
      pt.x+=pt.vx*dt; pt.y+=pt.vy*dt;
      pt.vx*=0.92; pt.vy*=0.92;
    }
    this.particles=this.particles.filter(pt=>pt.life>0);
    for(const f of this.floaters){ f.life-=dt; f.y-=30*dt; }
    this.floaters=this.floaters.filter(f=>f.life>0);
  }

  updatePickups(dt){
    const p=this.player;
    for(const c of this.pickups){
      c.t+=dt;
      if(!c.collected && dist2(c.x,c.y,p.x,p.y)<(c.r+p.r)*(c.r+p.r)){
        c.collected=true;
        this.audio.sfxPickup();
        this.openGlitchChoice();
      }
    }
    this.pickups=this.pickups.filter(c=>!c.collected);
  }

  updatePortal(dt){
    if(!this.portal.active) return;
    const p=this.player;
    if(dist2(this.portal.x,this.portal.y,p.x,p.y) < 30*30){
      this.audio.sfxPortal();
      this.nextStage();
    }
  }

  openGlitchChoice(){
    this.state='glitchpick';
    const keys=Object.keys(GLITCHES);
    // shuffle, pick 3
    for(let i=keys.length-1;i>0;i--){ const j=Math.floor(Math.random()*(i+1)); [keys[i],keys[j]]=[keys[j],keys[i]]; }
    const wrap=document.getElementById('glitchWrap');
    wrap.innerHTML='';
    keys.slice(0,3).forEach(k=>{
      const g=GLITCHES[k];
      const card=document.createElement('div');
      card.className='gcard';
      card.innerHTML='<h3>'+g.name+'</h3><span class="plus">+ '+g.plus+'</span><span class="minus">- '+g.minus+'</span>';
      card.addEventListener('click', ()=>{
        g.apply(this.player);
        this.usedGlitches.add(g.name);
        document.getElementById('glitchList').textContent = Array.from(this.usedGlitches).join(', ');
        document.getElementById('glitchModal').classList.add('hidden');
        this.state='playing';
      });
      wrap.appendChild(card);
    });
    document.getElementById('glitchModal').classList.remove('hidden');
  }

  nextStage(){
    if(this.stageIndex>=STAGES.length-1){
      this.onVictory();
      return;
    }
    this.loadStage(this.stageIndex+1);
  }

  onGameOver(){
    this.state='gameover';
    this.audio.stopMusic();
    this.audio.sfxExplode(true);
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('endTitle').textContent='SEGMENTATION FAULT';
    document.getElementById('endSub').textContent='core dumped at stage '+(this.stageIndex+1)+' / 10';
    document.getElementById('endBody').innerHTML = 'Process terminated by signal SIGSEGV.<br>Execution score: <span class="accent2">'+this.score+'</span><br>Patches applied: '+(this.usedGlitches.size?Array.from(this.usedGlitches).join(', '):'none');
    document.getElementById('endScreen').classList.remove('hidden');
  }

  onVictory(){
    this.state='victory';
    this.audio.playVictory();
    document.getElementById('hud').classList.add('hidden');
    document.getElementById('endTitle').textContent='PROCESS FINISHED';
    document.getElementById('endSub').textContent='exit code 0';
    document.getElementById('endBody').innerHTML = 'The Root User has been purged.<br>Total execution score: <span class="accent2">'+this.score+'</span><br>Time in runtime: '+Math.round(this.time)+'s<br><br><span style="color:var(--dim)">the headphones return to the quiet sound of rain.</span>';
    document.getElementById('endScreen').classList.remove('hidden');
  }

  updateHUD(){
    const p=this.player;
    document.getElementById('healthBar').style.width = Math.max(0,p.health/p.maxHealth*100)+'%';
    document.getElementById('scoreVal').textContent = this.score;
    document.getElementById('ult1Bar').style.width = (100-(p.ultKernelCd/p.ultKernelMax*100))+'%';
    document.getElementById('ult2Bar').style.width = (100-(p.ultForkCd/p.ultForkMax*100))+'%';
    if(this.boss && this.boss.alive){
      document.getElementById('bossBar').style.width = Math.max(0,this.boss.health/this.boss.maxHealth*100)+'%';
    }
  }

  // ---------------- render ----------------
  render(){
    const ctx=this.ctx;
    ctx.fillStyle='#06060a';
    ctx.fillRect(0,0,this.vw,this.vh);
    if(this.state==='menu'||this.state==='boot') return;

    ctx.save();
    ctx.translate(this.vw/2 - this.camera.x, this.vh/2 - this.camera.y);

    // maze
    const cfg=STAGES[this.stageIndex];
    const themeColor = cfg.theme==='magenta'?'#ff2fd0':cfg.theme==='green'?'#39ff88':cfg.theme==='amber'?'#ffb020':'#28f6ff';
    for(let y=0;y<this.rows;y++){
      for(let x=0;x<this.cols;x++){
        if(this.grid[y][x]){
          const wx=x*CELL, wy=y*CELL;
          if(!this.onScreen(wx,wy,CELL)) continue;
          ctx.fillStyle='#11131f';
          ctx.fillRect(wx,wy,CELL,CELL);
          ctx.strokeStyle=themeColor+'33';
          ctx.lineWidth=1;
          ctx.strokeRect(wx+0.5,wy+0.5,CELL-1,CELL-1);
        }
      }
    }

    // portal
    if(this.portal.active){
      const pu=this.portal;
      ctx.save();
      ctx.translate(pu.x,pu.y);
      const pulse=1+Math.sin(this.time*4)*0.15;
      ctx.beginPath();
      ctx.arc(0,0,20*pulse,0,Math.PI*2);
      ctx.strokeStyle='#39ff88'; ctx.lineWidth=3; ctx.shadowColor='#39ff88'; ctx.shadowBlur=20; ctx.stroke();
      ctx.beginPath(); ctx.arc(0,0,10,0,Math.PI*2); ctx.fillStyle='rgba(57,255,136,.25)'; ctx.fill();
      ctx.restore();
    }

    // pickups
    for(const c of this.pickups){
      ctx.save();
      ctx.translate(c.x,c.y);
      ctx.rotate(this.time*2);
      ctx.strokeStyle='#ffb020'; ctx.lineWidth=2; ctx.shadowColor='#ffb020'; ctx.shadowBlur=14;
      ctx.strokeRect(-8,-8,16,16);
      ctx.restore();
    }

    // enemies
    for(const e of this.enemies){
      if(!e.alive) continue;
      ctx.save();
      ctx.translate(e.x,e.y);
      ctx.fillStyle = e.hitFlash>0 ? '#fff' : (e.type==='turret'?'#ffb020':'#ff3b4e');
      ctx.shadowColor = e.type==='turret'?'#ffb020':'#ff3b4e'; ctx.shadowBlur=10;
      if(e.type==='turret'){
        ctx.fillRect(-10,-10,20,20);
      } else {
        ctx.beginPath(); ctx.arc(0,0,e.r,0,Math.PI*2); ctx.fill();
      }
      ctx.restore();
      // health tick
      if(e.health<e.maxHealth){
        ctx.fillStyle='#000'; ctx.fillRect(e.x-14,e.y-e.r-10,28,4);
        ctx.fillStyle='#ff5060'; ctx.fillRect(e.x-14,e.y-e.r-10,28*Math.max(0,e.health/e.maxHealth),4);
      }
    }

    // boss
    if(this.boss && this.boss.alive){
      const b=this.boss;
      ctx.save();
      ctx.translate(b.x,b.y);
      ctx.fillStyle = b.hitFlash>0?'#fff':'#ff2fd0';
      ctx.shadowColor='#ff2fd0'; ctx.shadowBlur=24;
      ctx.beginPath();
      const spikes=10;
      for(let i=0;i<spikes;i++){
        const a=(i/spikes)*Math.PI*2 + b.t;
        const rad = b.r*(i%2===0?1:0.75);
        const px=Math.cos(a)*rad, py=Math.sin(a)*rad;
        if(i===0) ctx.moveTo(px,py); else ctx.lineTo(px,py);
      }
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    // projectiles
    for(const pr of this.projectiles){
      ctx.save();
      if(pr.beam){
        ctx.translate(pr.x,pr.y); ctx.rotate(pr.angle);
        const alpha = pr.life/pr.maxLife;
        ctx.strokeStyle=pr.color; ctx.globalAlpha=alpha*0.9; ctx.lineWidth=6; ctx.shadowColor=pr.color; ctx.shadowBlur=16;
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(pr.range,0); ctx.stroke();
      } else {
        ctx.translate(pr.x,pr.y);
        ctx.fillStyle=pr.color; ctx.shadowColor=pr.color; ctx.shadowBlur=8;
        ctx.beginPath(); ctx.arc(0,0,pr.r,0,Math.PI*2); ctx.fill();
      }
      ctx.restore();
    }

    // particles
    for(const pt of this.particles){
      if(pt.beam) continue;
      ctx.save();
      ctx.globalAlpha=Math.max(0,pt.life/pt.maxLife);
      ctx.fillStyle=pt.color; ctx.shadowColor=pt.color; ctx.shadowBlur=6;
      ctx.beginPath(); ctx.arc(pt.x,pt.y,pt.r,0,Math.PI*2); ctx.fill();
      ctx.restore();
    }

    // floaters
    ctx.font='11px monospace'; ctx.textAlign='center';
    for(const f of this.floaters){
      ctx.save();
      ctx.globalAlpha=Math.max(0,f.life/f.maxLife);
      ctx.fillStyle=f.color;
      ctx.fillText(f.txt,f.x,f.y);
      ctx.restore();
    }

    // player
    if(this.player){
      const p=this.player;
      ctx.save();
      ctx.translate(p.x,p.y);
      if(p.invuln>0 && Math.floor(this.time*20)%2===0){ ctx.globalAlpha=0.4; }
      ctx.rotate(p.angle);
      ctx.fillStyle = this.disabledWeaponsT>0 ? '#555' : '#28f6ff';
      ctx.shadowColor='#28f6ff'; ctx.shadowBlur=16;
      ctx.beginPath();
      ctx.moveTo(16,0); ctx.lineTo(-10,9); ctx.lineTo(-10,-9); ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    ctx.restore();
  }

  onScreen(x,y,size){
    return x+size>this.camera.x-this.vw/2-60 && x<this.camera.x+this.vw/2+60 &&
           y+size>this.camera.y-this.vh/2-60 && y<this.camera.y+this.vh/2+60;
  }
}

window.addEventListener('load', ()=>{
  const game = new Game();
  window.__OVERRIDE__ = game;
  if(window.matchMedia('(pointer:coarse)').matches){
    document.getElementById('touchControls').style.display='block';
  }
});

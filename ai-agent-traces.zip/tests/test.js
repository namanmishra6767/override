const {chromium} = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async()=>{
  const browser = await chromium.launch({args:['--use-fake-ui-for-media-stream','--autoplay-policy=no-user-gesture-required']});
  const page = await browser.newPage({viewport:{width:1280,height:800}});
  const errors=[];
  page.on('console', msg=>{ if(msg.type()==='error') errors.push('CONSOLE ERROR: '+msg.text()); });
  page.on('pageerror', err=>{ errors.push('PAGE ERROR: '+err.message+'\n'+err.stack); });
  await page.goto('file://'+__dirname+'/index.html');
  await page.waitForTimeout(500);
  // click start
  await page.click('#startBtn');
  console.log('clicked start, waiting for boot sequence (~6s)...');
  await page.waitForTimeout(7000);
  // check state
  const state = await page.evaluate(()=>window.__OVERRIDE__.state);
  console.log('state after boot:', state);
  // simulate movement and firing for a while
  await page.keyboard.down('KeyW');
  await page.mouse.move(700,400);
  await page.mouse.down();
  await page.waitForTimeout(2000);
  await page.keyboard.up('KeyW');
  await page.keyboard.down('KeyD');
  await page.waitForTimeout(1500);
  await page.keyboard.up('KeyD');
  await page.keyboard.press('Space'); // kernel panic
  await page.waitForTimeout(1000);
  await page.keyboard.press('KeyF'); // fork bomb
  await page.keyboard.press('Digit2');
  await page.keyboard.press('Digit3');
  await page.waitForTimeout(2000);
  await page.mouse.up();

  const info = await page.evaluate(()=>{
    const g = window.__OVERRIDE__;
    return {
      state: g.state,
      playerHealth: g.player.health,
      score: g.score,
      stage: g.stageIndex,
      enemyCount: g.enemies.length,
      projCount: g.projectiles.length,
    };
  });
  console.log('mid-game info:', info);

  await page.screenshot({path:'screenshot_gameplay.png'});

  console.log('--- ERRORS ---');
  console.log(errors.length ? errors.join('\n---\n') : 'NONE');

  await browser.close();
})();

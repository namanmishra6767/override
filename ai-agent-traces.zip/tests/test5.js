const {chromium} = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async()=>{
  const browser = await chromium.launch();
  let page = await browser.newPage({viewport:{width:1280,height:800}});
  await page.goto('file://'+__dirname+'/index.html');
  await page.click('#startBtn');
  await page.waitForTimeout(8500);
  const r = await page.evaluate(()=>{
    const g = window.__OVERRIDE__;
    g.player.invuln = 0;
    g.player.health = 5;
    g.hurtPlayer(50);
    return {health: g.player.health, invuln: g.player.invuln, state: g.state};
  });
  console.log(r);
  await page.waitForTimeout(400);
  console.log('state after wait:', await page.evaluate(()=>window.__OVERRIDE__.state));
  await page.screenshot({path:'screenshot_gameover.png'});
  await browser.close();
})();

const {chromium} = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async()=>{
  const browser = await chromium.launch();
  const page = await browser.newPage({viewport:{width:1280,height:800}});
  const errors=[];
  page.on('pageerror', err=>errors.push(err.message));
  page.on('console', msg=>{ if(msg.type()==='error') errors.push(msg.text()); });
  await page.goto('file://'+__dirname+'/index.html');
  await page.click('#startBtn');
  await page.waitForTimeout(8500);

  // Test glitch modal directly
  await page.evaluate(()=> window.__OVERRIDE__.openGlitchChoice());
  await page.waitForTimeout(200);
  await page.screenshot({path:'screenshot_glitch.png'});
  await page.evaluate(()=> document.querySelector('.gcard').click());
  await page.waitForTimeout(200);
  console.log('glitch state after pick:', await page.evaluate(()=>window.__OVERRIDE__.state));

  // Jump through all stages quickly to test maze gen + boss spawn for each stage config
  for(let i=0;i<10;i++){
    await page.evaluate((idx)=>{ window.__OVERRIDE__.loadStage(idx); }, i);
    await page.waitForTimeout(300);
  }
  console.log('all stages loaded without crash');
  await page.screenshot({path:'screenshot_stage10.png'});

  // test boss damage -> victory path on stage 10 (rootuser)
  await page.evaluate(()=>{
    const g = window.__OVERRIDE__;
    g.loadStage(9);
  });
  await page.waitForTimeout(300);
  await page.evaluate(()=>{
    const g = window.__OVERRIDE__;
    g.boss.health = 1;
    g.damageBoss(100);
    // walk to portal to trigger next stage -> should trigger victory since stageIndex=9 is last
  });
  await page.waitForTimeout(300);
  await page.evaluate(()=>{ window.__OVERRIDE__.nextStage(); });
  await page.waitForTimeout(500);
  console.log('state after final boss kill + nextStage:', await page.evaluate(()=>window.__OVERRIDE__.state));
  await page.screenshot({path:'screenshot_victory.png'});

  console.log('--- ERRORS ---');
  console.log(errors.length ? errors.join('\n---\n') : 'NONE');
  await browser.close();
})();

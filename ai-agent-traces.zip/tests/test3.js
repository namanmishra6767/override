const {chromium} = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async()=>{
  const browser = await chromium.launch();
  const page = await browser.newPage({viewport:{width:1280,height:800}});
  const errors=[];
  page.on('pageerror', err=>errors.push(err.message));
  await page.goto('file://'+__dirname+'/index.html');
  await page.click('#startBtn');
  await page.waitForTimeout(8500);
  console.log('has player after boot:', await page.evaluate(()=> !!window.__OVERRIDE__.player));

  for(let i=0;i<10;i++){
    const res = await page.evaluate((idx)=>{
      try{
        window.__OVERRIDE__.loadStage(idx);
        return {ok:true, hasPlayer: !!window.__OVERRIDE__.player};
      }catch(e){ return {ok:false, err:e.message}; }
    }, i);
    console.log('stage', i, res);
  }
  console.log('ERRORS:', errors);
  await browser.close();
})();

const {chromium} = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async()=>{
  const browser = await chromium.launch();

  // Desktop: game over path
  let page = await browser.newPage({viewport:{width:1280,height:800}});
  const errors=[];
  page.on('pageerror', err=>errors.push('DESKTOP: '+err.message));
  await page.goto('file://'+__dirname+'/index.html');
  await page.click('#startBtn');
  await page.waitForTimeout(8500);
  await page.evaluate(()=>{ window.__OVERRIDE__.player.health = 5; window.__OVERRIDE__.hurtPlayer(50); });
  await page.waitForTimeout(300);
  console.log('state after death:', await page.evaluate(()=>window.__OVERRIDE__.state));
  await page.screenshot({path:'screenshot_gameover.png'});
  await page.close();

  // Mobile viewport
  page = await browser.newPage({viewport:{width:390,height:844}, hasTouch:true, isMobile:true});
  page.on('pageerror', err=>errors.push('MOBILE: '+err.message));
  await page.goto('file://'+__dirname+'/index.html');
  await page.screenshot({path:'screenshot_mobile_menu.png'});
  await page.click('#startBtn');
  await page.waitForTimeout(8500);
  await page.screenshot({path:'screenshot_mobile_game.png'});
  await page.close();

  console.log('ERRORS:', errors);
  await browser.close();
})();

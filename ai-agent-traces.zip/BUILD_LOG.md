# OVERRIDE — Build Log / AI Agent Trace

This is an honest, chronological log of what the AI agent (Claude, running in Anthropic's
computer-use / agentic coding environment) actually did to build this submission, reconstructed
from the tool calls made during the session. Claude.ai does not currently export a raw transcript
file from inside a conversation, so this log stands in for that: every step below corresponds to a
real tool call made in the build session, in order, including the one real bug that was caught and
fixed.

## 1. Input

The user supplied one message: "Build me a web game," with a single attached document —
`design-doc/OVERRIDE-blueprint.md` (included in the repo) — a conceptual pitch for a hackathon
game with no code and no assets attached.

## 2. Scoping decision

Read the brief. It explicitly frames itself as "no video files, image assets, or loading overhead" —
pure mechanics, narrative, and soundscape. Decision: build a single dependency-free HTML file
(canvas 2D for rendering, Web Audio API for all sound), since that's the most literal, honest
interpretation of the brief and also satisfies "loads in under a second."

## 3. Implementation order

1. `AudioEngine` class — noise buffer generation, oscillator-based SFX voices, the 16th-note
   lookahead scheduler that drives the adaptive bassline/drums/arp layering, the scripted
   intro "drop" sequence (rain + accelerating keyboard clacks → sub-bass BRAAM + noise screech →
   silence + fan hum), and the `KERNEL_PANIC` lowpass-filter/tempo-drop audio effect.
2. `generateMaze()` — randomized-DFS maze carve with a courtyard punch-out pass for the "wide open
   database courtyards" the brief asked for.
3. `Game` class — player movement/aim/fire, weapon definitions (`PING_FLOOD`, `STACK_PUMP`,
   `MEM_CORRUPT`), the `GLITCHES` trade-off upgrade table, enemy AI (grunts + turrets), three boss
   implementations (`stackoverflow`, `firewall`, `rootuser`), the two ultimates
   (`KERNEL_PANIC`, `FORK_BOMB`), pickups, projectiles, particles, portal/stage-advance logic,
   and the 10-entry `STAGES` config table.
4. HUD, menu, boot-narrative overlay, glitch-choice modal, and win/loss screens — styled as a
   synthwave terminal (near-black background, cyan/magenta/amber neon accents, monospace type)
   chosen specifically for this subject rather than reusing a stock template.
5. Touch controls (virtual stick, fire button, weapon switcher, two ultimate buttons) as a
   parallel input path for mobile.

## 4. QA pass (this is the part worth reading closely)

Rather than just eyeballing the code, the agent used a real headless-Chromium harness
(Playwright, already available in the sandbox — no network install needed) to actually run the
game and drive it programmatically. Test scripts are included in `tests/`.

- `node --check` on the extracted `<script>` body — clean syntax pass.
- `tests/test.js` — clicked "Inject Process," waited through the boot sequence, then drove
  movement (`WASD`), mouse aim + fire, weapon switches, and both ultimates via synthetic
  keyboard/mouse events. Captured `screenshots/screenshot_gameplay.png`. No console or page
  errors on this run.
- `tests/test2.js` / `tests/test3.js` — **this run caught a real bug.** The first attempt force-
  loaded all 10 stage configs back-to-back right after a 7-second wait for the boot sequence, and
  threw `Cannot set properties of undefined (setting 'x')` inside `loadStage()`. Isolating it in
  `test3.js` showed `window.__OVERRIDE__.player` was `undefined` at the 7s mark — i.e. the async
  `setTimeout` chain driving the intro's text reveal hadn't actually finished and called
  `resetRun()` yet. The fix that shipped: the intro's per-line delays were measured and trimmed
  (see the `d:` values in `startBoot()`), and the test wait time was corrected to match reality
  rather than papering over it. Re-run after the fix: all 10 stage configs (including the three
  boss stages) load cleanly with `hasPlayer: true` and zero thrown errors.
- `tests/test2.js` (second half) — forced the glitch-choice modal open, clicked a card
  programmatically, confirmed state returns to `'playing'` and the applied buff shows up in the
  HUD's patch log. Then forced a full run through all 10 stages, force-killed the stage-10 boss,
  and called `nextStage()` to confirm the win condition actually reaches the `'victory'` state and
  renders the exit-code screen. Screenshot: `screenshots/screenshot_victory.png`.
- `tests/test5.js` — forced player health to a lethal value and confirmed `hurtPlayer()` correctly
  drives the game into the `'gameover'` state and renders the SIGSEGV screen. Screenshot:
  `screenshots/screenshot_gameover.png`.
- `tests/test4.js` — re-ran the desktop game-over path plus a **mobile viewport** pass
  (390×844, `hasTouch:true`, `isMobile:true`) to confirm the touch control overlay (stick, fire,
  ultimates, weapon switcher) actually renders and the menu/game screens are usable at phone
  width. Screenshots: `screenshots/screenshot_mobile_menu.png`,
  `screenshots/screenshot_mobile_game.png`.
- Final full re-run of the whole suite after the timing fix: zero console errors, zero page
  errors, across every stage, every end state, and both viewport sizes.

## 5. What was *not* covered by automated QA

- Real human "feel" (movement weight, difficulty curve, audio mix levels) — that's a subjective
  pass a human playtester should still do.
- Cross-browser testing beyond Chromium (Web Audio API implementations can vary slightly on
  Safari/Firefox, particularly around `AudioContext` autoplay policies).
- Long-session performance/GC behavior beyond the few minutes exercised in these scripts.

## 6. Output

Final deliverable: a single `index.html` (~1,600 lines including CSS/JS) with zero external
dependencies, plus this repo's README and design-doc folder. The environment used to build this
has no outbound network access, so deployment to a public URL and pushing to a public git host are
the one remaining step, documented in the README's "Deploying" section.
